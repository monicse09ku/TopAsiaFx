<?php

// This is the database connection configuration.
return array(
	//'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',
	// uncomment the following lines to use a MySQL database
	
	'connectionString' => 'mysql:host=localhost;dbname=eabadat6_forex_db',
	'emulatePrepare' => true,
	'username' => 'eabadat6_forex',
	'password' => '{67sAU0zKp6_',
	'charset' => 'utf8',
	
);