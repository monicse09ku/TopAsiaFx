<div class="container" style="padding-bottom:20px;">
	<img class="img img-responsive" src="<?php echo Yii::app()->getBaseUrl(true);?>/images/404.jpg">
</div>