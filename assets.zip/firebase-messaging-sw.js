var cur_date = Math.floor(new Date())
importScripts("https://cdn.subscribers.com/assets/subscribers-sw.js?" + cur_date);
